# faylname = 'matn.txt'
# faylname = 'backend/fayllar/matn.txt'
# with open(faylname) as fayl:
#     matn = fayl.read()

# print(matn)

# fayl_pi = 'pi_million_digits.txt'
# with open(fayl_pi) as pi:
#     pi_million_digits = pi.read()
#     if '31032007' in pi_million_digits:
#         print("Sizning tug'ilgan yilingiz pi ichida bor ekan")
#     else:
#         print("Kechirasiz sizning tug'ilgan yilingiz pi ichida yo'q ekan")

# with open(faylomi,'a') as fayl:
#     fayl.write('Alijon Valiyev\n')
#     fayl.write('2000')

filename = "malumotlar.txt"

while True:
    data = input("Ma'lumot kiriting (chiqish uchun 'exit' deb yozing): ")
    
    if data.lower() == 'exit':
        print("Dastur tugadi.")
        break

    with open(filename, 'a') as file:
        file.write(data + "\n")

    print("Ma'lumot faylga saqlandi.\n")